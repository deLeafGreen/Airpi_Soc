#!/bin/bash



PIDEVICE=DATA
PIDIR=/mnt/usb

set -e

mkdir -p $PIDIR

if mount -L $PIDEVICE $PIDIR || echo error=$(mount -L $PIDEVICE $PIDIR) ;
then
    
    mkdir -p /mnt/usb/data/luftdruck

    /home/pi/airpiscripts/in_use/bmp085.py

    umount $PIDIR
    sync
fi