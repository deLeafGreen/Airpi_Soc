#!/bin/bash

DEVICE=data_pi
MNT_PI=/mnt/usb

mkdir -p $MNT_PI

if mount -L $DEVICE $MNT_PI || echo error=$(mount -L $DEVICE $MNT_PI) ;
then
    DATE=$(date +"%Y-%m_%d_%H%M")
    #raspistill -vf -hf -o /mnt/usb/$DATE.jpg

    mv ~pi/csv/* $MNT_PI
    umount $MNT_PI
    sync
fi

