import RPi.GPIO as GPIO
import sys
from time import *

GPIO.setmode(GPIO.BCM)

count = 0
string = ""
wtf = False

#Pins definieren
clock_signal = 25 
#15
signal_input = 23 
#25


#Pins sagen wozu sie da sind
GPIO.setup(clock_signal,GPIO.OUT)
GPIO.setup(signal_input,GPIO.IN)

while True:
    
    sleep(0.005)
    enno_sagt_piep = GPIO.output(clock_signal, True)
    sleep(0.01)
    enno_sagt_piep = GPIO.output(clock_signal,False)
    count = count + 1
    value = GPIO.input(signal_input) 
    
    string = string + "" + str(value)
    print string
    sleep(0.005)

    if count == 15:
        string = ""
        count = 0


    #enno_sagt_piep = GPIO.output(clock_signal, False)
    """
    if count == 1:
        if string == 0:
            print "Zero"
        else:
            count = 0
            string = ""
            print "no zero"
    elif count == 2:
        if string == "01":
            print "Zero One"
        else:
            count = 0
	            print "no Zero, no One"
	        string = ""
    elif count == 3 
        if string == "010":
            print string
		    print "Zero One Zero"
            wtf = True
        else :
		    print "no shit"
        	count = 0
		    string = ""
       """
       
       
       
       #print string
        #string = ""
        #count = 0
    
    if wtf and count == 8:
      print string
      count = 0
      string = ""

    #if count == 8:
     #       print string
      #      string = ""
       #     count = 0
        #    wtf = False

        #enno_sagt_piep = GPIO.output(clock_signal,False)
    #sys.stdout.write("%s " %value)
    
    #sleep(0.5)
